# sg-java-project-rep

Spring Boot Backend Application Name: SG
1) clone the project with name(SG) from git(https://github.com/vivek-singh1203/sg-java-project-rep.git).
2) Import as a maven project into your workspace.
Prerequisite
oracle database: Oracle 12c 12.1.0.1.0
java version: 1.8
Maven version: 3.3.3 and above
Command for running: run as java application/ spring boot application.
swagger
http://localhost:8090/v2/api-docs

***************************


UI Application name:: SGSampleApp
1) clone the project with name(SGSampleApp) from git(https://github.com/vivek-singh1203/sg-java-project-rep.git).
Prerequisite
NodeJs version:10.14.1

For downloading angular dependency: npm install

Command for running: ng serve (http://localhost:4200/)
Command for running: ng test.
