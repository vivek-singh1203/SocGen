import { EmployeeComponent } from './employee.component';
import { TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { EmployeeService } from '../services/employee.service';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('EmployeeService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [ReactiveFormsModule, FormsModule, HttpClientModule],
            declarations: [EmployeeComponent],
            schemas: [
                CUSTOM_ELEMENTS_SCHEMA,
                NO_ERRORS_SCHEMA
            ]
        })
            .compileComponents();
    });


    it('App should be created', () => {
        let fixture = TestBed.createComponent(EmployeeComponent);
        let app = fixture.debugElement.componentInstance;
        expect(app).toBeTruthy();
    })


    it('Employee Servive get Details method test', () => {
        let fixture = TestBed.createComponent(EmployeeComponent);
        let app = fixture.debugElement.componentInstance;
        let employeeService = fixture.debugElement.injector.get(EmployeeService)
        fixture.detectChanges();
        employeeService.getEmployee().subscribe(
            (data: any) => {
                expect(data.length.toBeGreaterThan(0))
            },
            (error) => {
                return console.log("Error message " + error);
            }
        )

    })
});