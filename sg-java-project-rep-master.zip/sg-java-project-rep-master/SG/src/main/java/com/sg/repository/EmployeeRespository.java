package com.sg.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sg.model.Employee;


@Repository
public interface EmployeeRespository extends CrudRepository<Employee, Long>{

}
