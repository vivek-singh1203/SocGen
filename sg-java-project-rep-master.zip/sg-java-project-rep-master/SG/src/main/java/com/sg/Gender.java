package com.sg;

public enum Gender {
	
	MALE,FEMALE

}
