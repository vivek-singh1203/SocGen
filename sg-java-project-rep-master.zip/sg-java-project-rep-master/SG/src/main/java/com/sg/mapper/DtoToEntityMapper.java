package com.sg.mapper;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.modelmapper.TypeMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sg.Gender;
import com.sg.dto.EmployeeDTO;
import com.sg.model.Employee;

@Component
public class DtoToEntityMapper {
	
	
	 @Autowired
	 private  ModelMapper modelMapper;
	
	public Employee convertToEntity(EmployeeDTO employeeDto){
		
		
		TypeMap<EmployeeDTO, Employee> typeMap = modelMapper.getTypeMap(EmployeeDTO.class, Employee.class);
		if (typeMap == null) { // if not  already added
			modelMapper.addMappings(skipModifiedFieldsMap);
		}
		
		Employee employee = modelMapper.map(employeeDto, Employee.class);
		
		try {
			employee.setDateOfBirth(new SimpleDateFormat("yyyy-MM-dd").parse(employeeDto.getDateOfBirth()));
			employee.setGender(Gender.valueOf(employeeDto.getGender()));
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		
		return employee;
		
		
	}
	
	 PropertyMap<EmployeeDTO, Employee> skipModifiedFieldsMap = new PropertyMap<EmployeeDTO, Employee>() {
	      protected void configure() {
	         skip().setDateOfBirth(null);;
	         
	     }
	   };

}
