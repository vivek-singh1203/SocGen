package com.sg.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sg.dto.EmployeeDTO;
import com.sg.mapper.DtoToEntityMapper;
import com.sg.model.Employee;
import com.sg.repository.EmployeeRespository;


@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRespository  employeeRespository ;
	
	@Autowired
	DtoToEntityMapper DtoToEntityMapper;
	

	public List<Employee> getEmployee(){
		return (List<Employee>) employeeRespository.findAll();
	}
	
	
	public Employee addEmployee(EmployeeDTO request){
		Employee employee = null;
		try {
			
			employee = DtoToEntityMapper.convertToEntity(request);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println(employee);
		return employeeRespository.save(employee);
	}

}
