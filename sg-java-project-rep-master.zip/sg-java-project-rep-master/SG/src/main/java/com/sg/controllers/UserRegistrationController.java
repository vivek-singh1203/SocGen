package com.sg.controllers;



import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sg.dto.EmployeeDTO;
import com.sg.model.Employee;
import com.sg.service.EmployeeService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value="employee")
public class UserRegistrationController {
	
	private static final Logger LOG = Logger.getLogger(UserRegistrationController.class.getName());
	
	@Autowired
	EmployeeService employeeService;
	
	
	@ApiOperation(value = "Get Employee Details", response = Employee.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully retrieved employee Details")})
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<Employee> allEmployees() {
		LOG.log(Level.INFO, employeeService.getEmployee());
		return employeeService.getEmployee();
	}
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public Employee addEmployee(@RequestBody EmployeeDTO request) {
		LOG.log(Level.INFO, request);
		
		return employeeService.addEmployee(request);
	}

}
