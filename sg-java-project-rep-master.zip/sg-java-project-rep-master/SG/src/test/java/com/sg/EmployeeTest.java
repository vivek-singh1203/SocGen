package com.sg;

import static org.junit.Assert.assertTrue;
import static org.testng.Assert.assertEquals;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;

import com.sg.dto.EmployeeDTO;
import com.sg.model.Employee;
import com.sg.service.EmployeeService;

@SpringBootTest(classes = SpringbootApplication.class)
public class EmployeeTest extends AbstractTransactionalTestNGSpringContextTests {

	@Autowired
	private EmployeeService employeeService;

	@Test
	public final void testGetEmployeeSuccessScenario() {

		List<Employee> employee = employeeService.getEmployee();

		System.out.println("Employee Size " + employee.size());
		assertTrue(employee.size() > 0);

	}

	@Test
	public final void testAddEmployeeSuccessScenario() {

		EmployeeDTO testRequest = new EmployeeDTO();
		testRequest.setFirstName("Test");
		testRequest.setLastName("Test");
		testRequest.setDateOfBirth("2018-01-22");
		testRequest.setGender("MALE");
		testRequest.setDepartment("IT");

		Employee employee = employeeService.addEmployee(testRequest);

		assertEquals(employee.getFirstName(), testRequest.getFirstName());

	}

}
